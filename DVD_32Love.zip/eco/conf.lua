function love.conf(t)
  t.title = "DVD"
  t.window.width = 1500
  t.window.height = 800
  end