function love.load()
   PositionLogoX = 100
   PositionLogoY = 100
   LargeurLogo = 206
   HauteurLogo = 103
   LargeurEcran = love.graphics.getWidth()
   HauteurEcran = love.graphics.getHeight()
   VitesseX = 1
   VitesseY = 1
   DVD = love.graphics.newImage("Assets/asset.jpg")
end

function love.update()
   PositionLogoX = PositionLogoX + VitesseX
   PositionLogoY = PositionLogoY +VitesseY
   if PositionLogoX >= LargeurEcran - LargeurLogo then VitesseX = -1 end
   if PositionLogoX <= 0 then VitesseX = 1 end
   if PositionLogoY >= HauteurEcran - HauteurLogo then VitesseY = -1 end
   if PositionLogoY <= 0 then VitesseY = 1 end
end

function love.draw()
    love.graphics.draw(DVD , PositionLogoX, PositionLogoY)
end